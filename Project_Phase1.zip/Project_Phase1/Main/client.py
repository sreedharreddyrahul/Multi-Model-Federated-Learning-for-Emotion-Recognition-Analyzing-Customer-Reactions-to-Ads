import os

import flwr as fl
import tensorflow as tf
from tensorflow import keras
import os

import flwr as fl
import tensorflow as tf
from tensorflow import keras
import random
#random.seed(0)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, BatchNormalization, MaxPool2D, Dropout, Flatten, Dense

from tensorflow.keras.optimizers import SGD
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
from tensorflow.keras import backend as K


# Make TensorFlow log less verbose
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import csv
import numpy
import numpy as np


# Make TensorFlow log less verbose
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

# Load model and data (MobileNetV2, CIFAR-10)
# model = tf.keras.applications.MobileNetV2((32, 32, 3), classes=10, weights=None)
# model.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])


# model = keras.Sequential([
#     keras.layers.Flatten(input_shape=(48,48)),
#     keras.layers.Dense(128, activation='relu'),
#     keras.layers.Dense(256, activation='relu'),
#     keras.layers.Dense(7, activation='softmax')
# ])
# model.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
# (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
def build_cnn():
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(48,48,1)))
    model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    #     # 2nd conv layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu'))
    model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    #     # 3rd conv layer
    model.add(keras.layers.Conv2D(32, (2, 2), activation='relu'))
    model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    # flatten output and feed it into dense layer
    model.add(keras.layers.Flatten())
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    # output layer
    model.add(keras.layers.Dense(7, activation='softmax'))
    model.add(keras.layers.Activation("softmax"))

    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    return model
def build_vgg_16():
    base_model = tf.keras.applications.VGG16(
    input_shape = (48, 48, 1), 
    include_top = False, 
    weights = None)
    #Start with a non trainable model
    base_model.trainable = False
    for layer in base_model.layers[:15]:
        layer.trainable = False
    x = base_model.output
    x = keras.layers.Flatten()(x) # Flatten dimensions to for use in FC layers
    x = keras.layers.Dense(512, activation='relu')(x)
    x = keras.layers.Dropout(0.5)(x) # Dropout layer to reduce overfitting
    x = keras.layers.Dense(256, activation='relu')(x)
    x = keras.layers.Dense(7, activation='softmax')(x) # Softmax for multiclass
    cnn = keras.Model(inputs=base_model.input, outputs=x)
    cnn.compile(loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return cnn

def build_resnet_50():
    base_model = tf.keras.applications.ResNet50(input_shape=(48,48,1),include_top=False,weights=None)
    for layer in base_model.layers[:-4]:
        layer.trainable=False
    model = Sequential()

    # 1 - Convolution 
    # extract relevant features from the images
    model.add(base_model) #adding base model of ResNet50
    model.add(BatchNormalization())  
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # 2nd Convolution layer
    # model.add(Conv2D(128,(5,5), padding='same'))
    # model.add(BatchNormalization())
    # model.add(Activation('relu'))
    # model.add(Dropout(0.25))

    # # 3rd Convolution layer
    # model.add(Conv2D(512,(3,3), padding='same'))
    # model.add(BatchNormalization())
    # model.add(Activation('relu'))
    # model.add(Dropout(0.25))

    # # 4th Convolution layer
    # model.add(Conv2D(512,(3,3), padding='same'))
    # model.add(BatchNormalization())
    # model.add(Activation('relu'))
    # model.add(Dropout(0.25))

    # Flattening
    model.add(Flatten())

    # Fully connected layer 1st layer
    # using these features to classify 
    model.add(Dense(256))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # Fully connected layer 2nd layer
    # model.add(Dense(512))
    # model.add(BatchNormalization())
    # model.add(Activation('relu'))
    # model.add(Dropout(0.25))

    model.add(Dense(7, activation='softmax'))
    model.compile(loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

model=build_cnn()



train_images = []
train_labels = []

test_images = []
test_labels = []

categories_count = {}

with open(r"C:\Users\sreed\VSCODE_CoDING\Project_Phase_1\Dataset\fer2013.csv") as train:

    # Read train.csv file
    csv_reader = csv.reader(train)
    next(csv_reader)  # Skip the header

    for row in csv_reader:

        # Append image
        if row[2] == 'Training':
            pixels_str = row[1]
            pixels_list = [int(i) for i in pixels_str.split(' ')]
            pixels_list = numpy.array(pixels_list, dtype='uint8')
            image = pixels_list.reshape((48, 48,1))
            train_images.append(image)

            label_str = row[0]

            # Calculate categories count
            count = 0
            if label_str in categories_count:
                count = categories_count[label_str] + 1
            categories_count[label_str] = count

            # Append label
            label = int(label_str)
            train_labels.append(label)
        elif row[2] == 'PublicTest':
            pixels_str = row[1]
            pixels_list = [int(i) for i in pixels_str.split(' ')]
            pixels_list = numpy.array(pixels_list, dtype='uint8')
            image = pixels_list.reshape((48, 48,1))
            test_images.append(image)

            label_str = row[0]

            # Calculate categories count
            count = 0
            if label_str in categories_count:
                count = categories_count[label_str] + 1
            categories_count[label_str] = count

            # Append label
            label = int(label_str)
            test_labels.append(label)
        else:
            pass
    

temp = list(zip(train_images, train_labels))
random.shuffle(temp)
train_images, train_labels = zip(*temp)
train_images, train_labels = list(train_images), list(train_labels)

temp1 = list(zip(test_images, test_labels))
random.shuffle(temp1)
test_images, test_labels = zip(*temp)
test_images, test_labels = list(test_images), list(test_labels)

x_train=numpy.array(train_images)
x_train_color=np.repeat(x_train, repeats=3, axis=3)
y_train=numpy.array(train_labels)

x_test=numpy.array(test_images)
x_test_color=np.repeat(x_test, repeats=3, axis=3)
y_test=numpy.array(test_labels)


model.fit(x_train[0:10], y_train[0:10], epochs=1)
print(x_train.shape,x_test.shape)


TRAIN_DATA_PER_CLIENT = 9569

# Train 3 times for each image
TRAINING_EPOCHS = 3



# Define Flower client
class My_CLient(fl.client.NumPyClient):
    def get_parameters(self, config):
        return model.get_weights()

    def fit(self, parameters, config,tr=True):
        model.set_weights(parameters)
        model.fit(x_train, y_train, epochs=1)
        return model.get_weights(), len(x_train), {}

    def evaluate(self, parameters, config):
        model.set_weights(parameters)
        loss, accuracy = model.evaluate(x_test, y_test)
        return loss, len(x_test), {"accuracy": accuracy}


# Start Flower client
fl.client.start_numpy_client(server_address="127.0.0.1:8080", client=My_CLient())