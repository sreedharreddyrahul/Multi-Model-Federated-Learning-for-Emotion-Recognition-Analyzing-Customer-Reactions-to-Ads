import flwr as fl
import numpy as np
import os
import time
import os

import flwr as fl
import tensorflow as tf
from tensorflow import keras

import os

import flwr as fl
import tensorflow as tf
from tensorflow import keras
import random

import random
import numpy as np # linear algebra
import numpy
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os,cv2
import numpy as np
import os


random.seed(0)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, BatchNormalization, MaxPool2D, Dropout, Flatten, Dense

from tensorflow.keras.optimizers import SGD
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
from tensorflow.keras import backend as K

class SaveModelStrategy(fl.server.strategy.FedAvg):
    def build_cnn():
        model = keras.Sequential()

        # 1st conv layer
        model.add(keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(48,48,1)))
        model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
        model.add(keras.layers.BatchNormalization())

        #     # 2nd conv layer
        model.add(keras.layers.Conv2D(32, (3, 3), activation='relu'))
        model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
        model.add(keras.layers.BatchNormalization())

        #     # 3rd conv layer
        model.add(keras.layers.Conv2D(32, (2, 2), activation='relu'))
        model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), padding='same'))
        model.add(keras.layers.BatchNormalization())

        # flatten output and feed it into dense layer
        model.add(keras.layers.Flatten())
        model.add(keras.layers.Dense(64, activation='relu'))
        model.add(keras.layers.Dropout(0.3))

        # output layer
        model.add(keras.layers.Dense(7, activation='softmax'))
        model.add(keras.layers.Activation("softmax"))

        optimiser = keras.optimizers.Adam(learning_rate=0.0001)
        model.compile(optimizer=optimiser,
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])
        return model
    model=build_cnn()
    def aggregate_fit(
        self,
        rnd,
        results,
        failures
    ):
        aggregated_weights = super().aggregate_fit(rnd, results, failures)
        aggregated_parameters, aggregated_metrics = super().aggregate_fit(rnd, results, failures)
        aggregated_ndarrays: List[np.ndarray] = fl.common.parameters_to_ndarrays(aggregated_parameters)
        if aggregated_weights is not None and rnd>99:
            # Save aggregated_weights
            self.model.set_weights(aggregated_ndarrays)
            print(f"Saving round {rnd} aggregated_weights...")
            timestamp = time.strftime("%d-%b-%Y")
            timestamp_1 = time.strftime("%d-%b-%Y-%H_%M_%S")
            if not (os.path.exists("weights_"+timestamp_1)):
                os.mkdir(f"weights_{timestamp_1}")
            self.model.save_weights(f"CNN_model.h5")
            # self.model.save(f"weights_{timestamp_1}/")
            # np.savez(f"weights_{timestamp}/round-{rnd}-weights-{timestamp_1}.npz", *aggregated_weights)
        return aggregated_weights

# Create strategy and run server
strategy = SaveModelStrategy()


# Start Flower server
fl.server.start_server(
    server_address="0.0.0.0:8080",
    config=fl.server.ServerConfig(num_rounds=100),
    strategy = strategy
)