import subprocess
import animation
#RAVDESS
features_1 = ['Federated_RAVDESS_MFCC.json','Federated_RAVDESS_Chroma_stft.json','Federated_RAVDESS_Chroma_CENS.json','Federated_RAVDESS_Chroma_CQT.json','Federated_RAVDESS_SDCC.json','Federated_RAVDESS_Spectral_Contrast.json','Federated_RAVDESS_ZCR.json','Federated_RAVDESS_RMS.json','Federated_RAVDESS_SB.json','Federated_RAVDESS_SC.json','Federated_RAVDESS_SR.json','Federated_RAVDESS_Mel_spectrogram.json']
features_2 = ['Federated_RAVDESS_MFCC.json','Federated_RAVDESS_Chroma_stft.json','Federated_RAVDESS_Chroma_CENS.json','Federated_RAVDESS_Chroma_CQT.json','Federated_RAVDESS_SDCC.json','Federated_RAVDESS_Spectral_Contrast.json','Federated_RAVDESS_ZCR.json','Federated_RAVDESS_RMS.json','Federated_RAVDESS_SB.json','Federated_RAVDESS_SC.json','Federated_RAVDESS_SR.json','Federated_RAVDESS_Mel_spectrogram.json']

#TESS
# features_1 = ['Federated_MFCC.json','Federated_Chroma_stft.json','Federated_Chroma_CENS.json','Federated_Chroma_CQT.json','Federated_SDCC.json','Federated_Spectral_Contrast.json','Federated_ZCR.json','Federated_RMS.json','Federated_SB.json','Federated_SC.json','Federated_SR.json','Federated_Mel_spectrogram.json']

# features_2 = ['Federated_MFCC.json','Federated_Chroma_stft.json','Federated_Chroma_CENS.json','Federated_Chroma_CQT.json','Federated_SDCC.json','Federated_Spectral_Contrast.json','Federated_ZCR.json','Federated_RMS.json','Federated_SB.json','Federated_SC.json','Federated_SR.json','Federated_Mel_spectrogram.json']


def feature_modelling(features_1,features_2):
    
    commands = [
        'start /wait cmd.exe /c python C:/Users/sreed/VSCODE_CoDING/Project_Phase_1/Flower_Federated/Main/server.py {} {}'.format(features_1, features_2),
        'start /wait cmd.exe /c python C:/Users/sreed/VSCODE_CoDING/Project_Phase_1/Flower_Federated/Main/client.py {} {}'.format(features_1, features_2),
        'start /wait cmd.exe /c python C:/Users/sreed/VSCODE_CoDING/Project_Phase_1/Flower_Federated/Main/client2.py {} {}'.format(features_1, features_2)
    ]

    # Create a subprocess for each command
    processes = []
    for command in commands:
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,shell=True)
        processes.append(process)
    return processes

total_processes = 0

for i in range(len(features_1)): 
    for j in range(i,len(features_2)):
        if i!=j:
            total_processes+=1
        else:
            pass
        
executing = 0

clock = ['-','\\','|','/']

for i in range(4,5): 
    for j in range(i+1,i+2):
        if i!=j:
            wait_animation = animation.Wait(clock)
            print('--> {} / {} Executing {} {}'.format(executing, total_processes,features_1[i],features_2[j]),end=' ')
            wait_animation.start()
            processes = feature_modelling(features_1[i],features_2[j])
            processes[0].wait()
            wait_animation.stop()
            executing+=1
            print('{} / {} :)Done with {} {}'.format(executing, total_processes,features_1[i],features_2[j]))
        else:
            continue
        
        
    


    