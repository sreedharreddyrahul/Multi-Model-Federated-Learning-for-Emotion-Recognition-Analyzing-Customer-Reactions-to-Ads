import flwr as fl
import os
import time
import tensorflow as tf
from tensorflow import keras
import random
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
random.seed(0)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, BatchNormalization, MaxPool2D, Dropout, Flatten, Dense
from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
from sklearn.model_selection import train_test_split
import sys
from typing import Dict, Optional, Tuple
from pathlib import Path
import random
random.seed(0)
import json
import warnings
warnings.filterwarnings("ignore")

DATA_PATH = r"C:\Users\sreed\VSCODE_CoDING\Project_Phase_1\Speech_strand\Features\{}".format(sys.argv[1])
DATA_PATH1 = r"C:\Users\sreed\VSCODE_CoDING\Project_Phase_1\Speech_strand\Features\{}".format(sys.argv[2])

print("Feature 1: ",DATA_PATH)
print("Feature 2: ",DATA_PATH1)

# with open('Speech_strand/LSTM_GRU_RAVDESS_Mix_Features/{}_{}_server.txt'.format((sys.argv[1]).split('.json')[0],sys.argv[2].split('.json')[0]), 'w') as f:
#     f.write('Feature 1: {} \n'.format(sys.argv[1]))
#     f.write('Feature 2: {} \n'.format(sys.argv[2]))
#     f.close()
    
    
def load_data(data_path,data_path1):
    with open(data_path, "r") as fp:
        data = json.load(fp)
    X = np.array(data["mfcc"])
    y = np.array(data["labels"])
    
    print(y.shape)
    
    with open(data_path1, "r") as fp:
        data1 = json.load(fp)
    X1 = np.array(data1["mfcc"])
    y1 = np.array(data1["labels"])
    fin=[]
    for i in range(len(data["mfcc"])):
        h=[]
        for j in range(len(data1["mfcc"][0])):
            h.append(data["mfcc"][i][j]+data1["mfcc"][i][j])
        fin.append(h)
    X = np.array(fin)
    y = np.array(data["labels"])
    return X,y
    
X, y = load_data(DATA_PATH,DATA_PATH1)
temp = list(zip(X, y))
random.shuffle(temp)
images, labels = zip(*temp)
# res1 and res2 come out as tuples, and so must be converted to lists.
images, labels = list(images), list(labels)

X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=0.1)
X_train, X_validation, y_train, y_validation = train_test_split(X_train, y_train, test_size=0.1)

#print(train_images.shape, test_images.shape, train_labels.shape, test_labels.shape)

x_val=np.array(X_validation)
y_val=np.array(y_validation)

def build_lstm_gru(input_shape):
    # build network topology
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.LSTM(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.GRU(64))

    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    model.add(keras.layers.Dense(7, activation='softmax'))
    
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy'])

    return model

def build_model_lstm(input_shape):

        # build network topology
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.LSTM(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.LSTM(64))

    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    model.add(keras.layers.Dense(7, activation='softmax'))
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy'])

    return model

def build_model_GRU(input_shape):

# build network topology
    model = keras.Sequential()

    model.add(keras.layers.GRU(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.GRU(64))

        # dense layer
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

        # output layer
    model.add(keras.layers.Dense(7, activation='softmax'))
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy'])

    return model

def main() -> None:
    # Load and compile model for
    # 1. server-side parameter initialization
    # 2. server-side parameter evaluation
    input_shape = (X_train.shape[1], X_train.shape[2])
    print(X_train.shape[0],X_train.shape[1], X_train.shape[2])
    model = build_model_GRU(input_shape)
    # Create strategy
    strategy = fl.server.strategy.FedAvg(
        fraction_fit=0.3,
        fraction_evaluate=0.2,
        min_fit_clients=2,
        min_evaluate_clients=2,
        min_available_clients=2,
        evaluate_fn=get_evaluate_fn(model),
        on_fit_config_fn=fit_config,
        on_evaluate_config_fn=evaluate_config,
        initial_parameters=fl.common.ndarrays_to_parameters(model.get_weights()),
    )

    # Start Flower server (SSL-enabled) for four rounds of federated learning
    fl.server.start_server(
        server_address="0.0.0.0:8080",
        config=fl.server.ServerConfig(num_rounds=100),
        strategy=strategy,
        # certificates=(
        #     Path(".cache/certificates/ca.crt").read_bytes(),
        #     Path(".cache/certificates/server.pem").read_bytes(),
        #     Path(".cache/certificates/server.key").read_bytes(),
        # ),
    )


def get_evaluate_fn(model):
    """Return an evaluation function for server-side evaluation."""

    def evaluate(
        server_round: int,
        parameters: fl.common.NDArrays,
        config: Dict[str, fl.common.Scalar],
    ) -> Optional[Tuple[float, Dict[str, fl.common.Scalar]]]:
        model.set_weights(parameters)  # Update model with the latest parameters
        loss, accuracy = model.evaluate(x_val, y_val)
        # with open('Speech_strand/LSTM_GRU_RAVDESS_Mix_Features/{}_{}_server.txt'.format((sys.argv[1]).split('.json')[0],sys.argv[2].split('.json')[0]), 'a') as f:
        #     f.write('Round: {} , Loss: {} , Accuracy: {} \n'.format(server_round,loss,accuracy))
        if server_round>=1:
            #weights = model.get_weights()
            print(f"Saving round {server_round} aggregated_weights...")
            model.save_weights('C:/Users/sreed/VSCODE_CoDING/Project_Phase_1/Speech_strand/{}_{}_aggregated_weights.h5'.format((sys.argv[1]).split('.json')[0],sys.argv[2].split('.json')[0]))
            
        return loss, {"accuracy": accuracy}
    
    return evaluate


def fit_config(server_round: int):
    """Return training configuration dict for each round.
    Keep batch size fixed at 32, perform two rounds of training with one
    local epoch, increase to two local epochs afterwards.
    """
    config = {
        "batch_size": 32,
        "local_epochs": 1 if server_round < 2 else 2,
    }
    return config


def evaluate_config(server_round: int):
    """Return evaluation configuration dict for each round.
    Perform five local evaluation steps on each client (i.e., use five
    batches) during rounds one to three, then increase to ten local
    evaluation steps.
    """
    val_steps = 5 if server_round < 4 else 10
    return {"val_steps": val_steps}


if __name__ == "__main__":
    main()
