import flwr as fl
import tensorflow as tf
from tensorflow import keras
import os
import random
random.seed(0)
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, BatchNormalization, MaxPool2D, Dropout, Flatten, Dense
from tensorflow.keras.applications.resnet50 import ResNet50
from tensorflow.keras.optimizers import SGD
from tensorflow.keras.losses import SparseCategoricalCrossentropy
from tensorflow.keras.metrics import SparseCategoricalAccuracy
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import MaxPooling2D
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import SGD
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
import sys
import json
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow.keras as keras
import matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold
import warnings
warnings.filterwarnings("ignore")

DATA_PATH = r"C:\Users\sreed\VSCODE_CoDING\Project_Phase_1\Speech_strand\Features\{}".format(sys.argv[1])
DATA_PATH1 = r"C:\Users\sreed\VSCODE_CoDING\Project_Phase_1\Speech_strand\Features\{}".format(sys.argv[2])

print("Feature 1: ",DATA_PATH)
print("Feature 2: ",DATA_PATH1)

# with open('Speech_strand/LSTM_GRU_RAVDESS_Mix_Features/{}_{}_client.txt'.format((sys.argv[1]).split('.json')[0],sys.argv[2].split('.json')[0]), 'w') as f:
#     f.write('Feature 1: {} \n'.format(sys.argv[1]))
#     f.write('Feature 2: {} \n'.format(sys.argv[2]))
#     f.close()
    

def build_cnn():
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(48,48,1)))
    model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    #     # 2nd conv layer
    model.add(keras.layers.Conv2D(32, (3, 3), activation='relu'))
    model.add(keras.layers.MaxPooling2D((3, 3), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    #     # 3rd conv layer
    model.add(keras.layers.Conv2D(32, (2, 2), activation='relu'))
    model.add(keras.layers.MaxPooling2D((2, 2), strides=(2, 2), padding='same'))
    model.add(keras.layers.BatchNormalization())

    # flatten output and feed it into dense layer
    model.add(keras.layers.Flatten())
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    # output layer
    model.add(keras.layers.Dense(7, activation='softmax'))
    model.add(keras.layers.Activation("softmax"))

    optimizer = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimizer,
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])
    return model

def build_model_lstm(input_shape):

    # build network topology
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.LSTM(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.LSTM(64))

    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    model.add(keras.layers.Dense(7, activation='softmax'))
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy'])

    return model

def build_vgg_16():
    base_model = tf.keras.applications.VGG16(
    input_shape = (48, 48, 1), 
    include_top = False, 
    weights = None)
    #Start with a non trainable model
    base_model.trainable = False
    for layer in base_model.layers[:15]:
        layer.trainable = False
    x = base_model.output
    x = keras.layers.Flatten()(x) # Flatten dimensions to for use in FC layers
    x = keras.layers.Dense(512, activation='relu')(x)
    x = keras.layers.Dropout(0.5)(x) # Dropout layer to reduce overfitting
    x = keras.layers.Dense(256, activation='relu')(x)
    x = keras.layers.Dense(7, activation='softmax')(x) # Softmax for multiclass
    cnn = keras.Model(inputs=base_model.input, outputs=x)
    cnn.compile(loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return cnn

def build_resnet_50():
    base_model = tf.keras.applications.ResNet50(input_shape=(48,48,1),include_top=False,weights=None)
    for layer in base_model.layers[:-4]:
        layer.trainable=False
    model = Sequential()

    # 1 - Convolution 
    # extract relevant features from the images
    model.add(base_model) #adding base model of ResNet50
    model.add(BatchNormalization())  
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # 2nd Convolution layer
    model.add(Conv2D(128,(5,5), padding='same'))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # 3rd Convolution layer
    model.add(Conv2D(512,(3,3), padding='same'))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # 4th Convolution layer
    model.add(Conv2D(512,(3,3), padding='same'))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # Flattening
    model.add(Flatten())

    # Fully connected layer 1st layer
    # using these features to classify 
    model.add(Dense(256))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    # # Fully connected layer 2nd layer
    model.add(Dense(512))
    model.add(BatchNormalization())
    model.add(Activation('relu'))
    model.add(Dropout(0.25))

    model.add(Dense(7, activation='softmax'))
    model.compile(loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

def build_lstm_gru(input_shape):
    # build network topology
    model = keras.Sequential()

    # 1st conv layer
    model.add(keras.layers.LSTM(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.GRU(64))

    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

    model.add(keras.layers.Dense(7, activation='softmax'))
    
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy'])

    return model

def build_model_GRU(input_shape):

    # build network topology
    model = keras.Sequential()

    model.add(keras.layers.GRU(128, input_shape=input_shape, return_sequences=True))
    model.add(keras.layers.GRU(64))

          # dense layer
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dropout(0.3))

          # output layer
    model.add(keras.layers.Dense(7, activation='softmax'))
    
    optimiser = keras.optimizers.Adam(learning_rate=0.0001)
    model.compile(optimizer=optimiser,
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy'])

    return model



def load_data(data_path,data_path1):
    with open(data_path, "r") as fp:
        data = json.load(fp)
    X = np.array(data["mfcc"])
    y = np.array(data["labels"])
    
    print(y.shape)
    
    with open(data_path1, "r") as fp:
        data1 = json.load(fp)
    X1 = np.array(data1["mfcc"])
    y1 = np.array(data1["labels"])
    fin=[]
    for i in range(len(data["mfcc"])):
        h=[]
        for j in range(len(data1["mfcc"][0])):
            h.append(data["mfcc"][i][j]+data1["mfcc"][i][j])
        fin.append(h)
    X = np.array(fin)
    y = np.array(data["labels"])
    return X,y
    
X, y = load_data(DATA_PATH,DATA_PATH1)
temp = list(zip(X, y))
random.shuffle(temp)
train_mfcc, train_labels = zip(*temp)
# res1 and res2 come out as tuples, and so must be converted to lists.
images, labels = list(train_mfcc), list(train_labels)
# Create numpy array of train images and labels
#print(images)
#print(labels)
X_train, X_test, y_train, y_test = train_test_split(images, labels, test_size=0.2)
X_train, X_validation, y_train, y_validation = train_test_split(X_train, y_train, test_size=0.2)

#print(train_images.shape, test_images.shape, train_labels.shape, test_labels.shape)

x_train=np.array(X_train)
#x_train = numpy.reshape(x_train, (x_train[0], 1, x_train.shape[1]))[0]
#x_train_color=np.repeat(x_train, repeats=1, axis=0)
y_train=np.array(y_train)

x_test=np.array(X_test)
#x_test = numpy.reshape(x_test, (x_test[0], 1, x_test.shape[1]))[0]
#x_test_color=np.repeat(x_test, repeats=1, axis=0)
y_test=np.array(y_test)

print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

model = build_model_GRU((x_train.shape[1],x_train.shape[2]))

model.fit(x_train, y_train,epochs=1, verbose=2)
print(x_train.shape,x_test.shape)


#TRAIN_DATA_PER_CLIENT = 9569

# Train 3 times for each image
#TRAINING_EPOCHS = 3



# Define Flower client
class My_CLient(fl.client.NumPyClient):
    def get_parameters(self, config):
        return model.get_weights()

    def fit(self, parameters, config,tr=True):
        model.set_weights(parameters)
        model.fit(x_train, y_train, epochs=1, verbose=2)
        return model.get_weights(), len(x_train), {}

    def evaluate(self, parameters, config):
        model.set_weights(parameters)
        loss, accuracy = model.evaluate(x_test, y_test)
        # with open('Speech_strand/LSTM_GRU_RAVDESS_Mix_Features/{}_{}_client.txt'.format((sys.argv[1]).split('.json')[0],sys.argv[2].split('.json')[0]), 'a') as f:
        #     f.write('Loss: {} , Accuracy: {} \n'.format(loss,accuracy))
        #     f.close()
        # if rounds>99:
        #     f.close()
        return loss, len(x_test), {"accuracy": accuracy}


# Start Flower client
fl.client.start_numpy_client(server_address="127.0.0.1:8080", client=My_CLient())